import snap7
from importlib.metadata import version
print("Biblioteka snap7 w wersji: ", version("python-snap7"))