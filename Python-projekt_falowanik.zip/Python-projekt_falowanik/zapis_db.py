import snap7
from snap7 import util

#Ustawienia połączenia z PLC
ip_plc = "10.10.7.10"
rack = 0
slot = 1
nr_db = 10

#Adresy zmiennych
bajt_zalacz = 0 # Offset : 0.0
bit_zalacz = 0
bajt_wartosc_zadan = 2 # offset : 2.0 (Real, 4 bajty)

#Dopuszczalny zakres częstotliwości
min_hz = 0
max_hz = 50.0

#Funkcja połączenia
def polacz():
    klient = snap7.client.Client()
    klient.connect(ip_plc, rack, slot)
    return klient

#Funkcja odczyt
def odczytaj_dane(klient):
    dane = klient.db_read(nr_db, 0, 8)
    zalacz = util.get_bool(dane, 0, 0)
    wartosc_zadana = util.get_real(dane, 2)
    licznik = util.get_int(dane, 6)
    return zalacz, wartosc_zadana, licznik

#Funkcja zapis bitu zalacz na true lub false
def zapisz_zalacz(klient, stan):
    dane = klient.db_read(nr_db, bajt_zalacz, 1)
    util.set_bool(dane, 0, bit_zalacz, stan)
    klient.db_write(nr_db, bajt_zalacz, dane)

#funkcja sprawdzenie zakresu czestotlwiosci
def sprawdz_czestotliwosc(hz):
    if not min_hz <= hz <= max_hz:
        raise ValueError(f"Częstotliwość: {hz} Hz jest poza zakresem {min_hz} - {max_hz} HZ")
    return hz

#funkcja zapis wartosci zadanej
def zapisz_wartosc_zadana(klient, hz):
    sprawdz_czestotliwosc(hz)
    dane = bytearray(4) #tworzy 4 bajty puste
    util.set_real(dane, 0, hz)
    klient.db_write(nr_db, bajt_wartosc_zadan, dane)

#Program główny
klient = None

try:
    print(f"Łączenie ze sterownikiem....................")
    klient = polacz()
    if klient.get_connected():
        print(f"Połączono ze sterownikiem")

    print("Przed zapisem: ", odczytaj_dane(klient))

    zapisz_zalacz(klient, False)
    zapisz_wartosc_zadana(klient, 60.0)
    print("Zapisano: Załącz: False; Wartość zadana: 25.0")
    print("Po zapisie", odczytaj_dane(klient))

except ValueError as e:
    print(f"Odrzucono wartość: {e}")

except Exception as e:
    print(f"Błąd komunikacji: {e}")

finally:
    if klient is not None and klient.get_connected():
        klient.disconnect()
        print("Rozłączono")



