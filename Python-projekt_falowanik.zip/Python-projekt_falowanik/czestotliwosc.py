import snap7
from snap7 import util
import time

#   ===== Konfiguracja połączenia =====
CPU_IP = "10.10.7.10"
RACK = 0
SLOT = 1

#   ===== Adresy markerów =====
BAJT_POTWIERDZENIA = 0 #M0.2
BIT_POTWIERDZENIA = 2
BAJT_CZEST_ZADANA = 14 #MD14
BAJT_CZEST_RZECZYWISTA = 2 #MD2

MIN_HZ = 0
MAX_HZ = 50

#   ===== Funkcje =====
def polacz():
    klient = snap7.client.Client()
    klient.connect(CPU_IP, RACK, SLOT)
    return klient

def sprawdz_czestotliwosc(hz):
    if not MIN_HZ <= hz <= MAX_HZ:
        raise ValueError(f"Częstotliwość {hz} Hz jest poza zakresem")
    return hz

def czy_potwierdzenie(klient):
    dane = klient.mb_read(BAJT_POTWIERDZENIA, 1)
    potwierdzenie_on = util.get_bool(dane, 0, BIT_POTWIERDZENIA)
    return potwierdzenie_on

def odczyt_czesto_rzeczyw(klient):
    dane = klient.mb_read(BAJT_CZEST_RZECZYWISTA, 4)
    czesto_rzeczyw = util.get_real(dane, 0)
    return czesto_rzeczyw

def wyslij_czestotliwosc(klient, hz): #zadana %MD14
    dane = bytearray(4)
    util.set_real(dane, 0, hz)
    klient.mb_write(BAJT_CZEST_ZADANA, 4, dane)

def pobierz_czestotliwosc_terminal():
    while True:
        try:
            czestotliwosc_zadana = float(input("Podaj częstotliwość zadaną: "))
            sprawdz_czestotliwosc(czestotliwosc_zadana)
            return czestotliwosc_zadana
        except ValueError as e:
            print(f"Błąd: {e}")

#   ===== Kod główny =====
klient = None
try:
    czesto_zadana = pobierz_czestotliwosc_terminal()

    print("Łączenie ze sterownikiem............")
    klient = polacz()
    if klient.get_connected():
        print("Połączono ze sterownikiem")
    
    stan_potwierdzenia = czy_potwierdzenie(klient)
    print(f"Stan potwierdzenia: {stan_potwierdzenia}")

    if not stan_potwierdzenia:
        print("Włącz potwierdzenie zadania częstotliwości na HMI")
    else:
        wyslij_czestotliwosc(klient, czesto_zadana)
        print(f"Zadano wartość częstotliwości = {czesto_zadana} Hz")
        time.sleep(5)
        czesto_rzeczyw = odczyt_czesto_rzeczyw(klient)
        print(f"Odczytana częstotliwość rzeczywista: {czesto_rzeczyw:.2f} Hz")

except ValueError as e:
    print(f"Odrzucono wartość: {e}")

except Exception as e:
    print(f"Błąd komunikacji: {e}")

finally:
    if klient is not None and klient.get_connected():
        klient.disconnect()
        print("Rozłączono")
