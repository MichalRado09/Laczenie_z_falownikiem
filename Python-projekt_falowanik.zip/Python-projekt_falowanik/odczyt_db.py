import snap7
from snap7 import util

#Ustawienia połączenia z PLC
ip_plc = "10.10.7.10"
rack = 0
slot = 1
nr_db = 10

# Łączenie ze sterownikiem
def polacz():
    klient = snap7.client.Client()
    klient.connect(ip_plc, rack, slot)
    return klient

# Odczyt 8 bajtow z db10 i zmiana ich na wartości
def odczytaj_dane(klient):
    dane = klient.db_read(nr_db, 0, 8)
    zalacz = util.get_bool(dane, 0, 0)
    wartosc_zadana = util.get_real(dane, 2)
    licznik = util.get_int(dane, 6)
    return zalacz, wartosc_zadana, licznik


# Program główny
klient = None
try:
    print(f"Łączenie ze sterownikiem {ip_plc}........")
    klient = polacz()
    if klient.get_connected():
        print("Połączono")

    zalacz, wartosc_zadana, licznik = odczytaj_dane(klient) # rozpakowanie do trzech zmiennych uzywajac funkcji odcztaj_dane

    print(f"Załącz: {zalacz}")
    print(f"Wartosc_zadana: {wartosc_zadana}")
    print(f"licznik_testowy: {licznik}")

except Exception as e:
    print(f"Błąd komunikacji: {e}")

finally:
    if klient is not None and klient.get_connected():
        klient.disconnect()
        print("Rozłączono ze sterownikiem")


